import type { CSSProperties, ComponentType } from "react";
import { View, type StyleProp, type ViewStyle } from "react-native";
import {
  isTrackReference,
  LiveKitRoom as ComponentsLiveKitRoom,
  useIsMuted,
  useParticipants,
  useRoomContext,
  useTracks,
  VideoTrack as ComponentsVideoTrack,
} from "@livekit/components-react";
import type { TrackReference } from "@livekit/components-core";
import { DisconnectReason, LocalVideoTrack, RoomEvent, Track } from "livekit-client";
import type { Track as LiveKitTrack } from "livekit-client";
import type { Participant } from "livekit-client";

export { isTrackReference, useIsMuted, useParticipants, useRoomContext, useTracks };
export type { Participant };
export type { DisconnectReason };

// ↔ نفس الواجهة الموحّدة اللي بقت مستخدمة فى الملف المقابل native.tsx —
// على الويب مفيش مشكلة استيراد eager أصلاً (السبب فى native.tsx كان
// خاص بترتيب تحميل Metro الكسول للمسارات على الموبايل)، لكن الدوال دي
// موجودة هنا بنفس الاسم عشان نقاط الاستخدام المشتركة (broadcast.tsx،
// [id].tsx، useLiveKitRoom.ts) تنادي نفس الـ API بغض النظر عن المنصة.
export function getTrackEnum(): typeof Track {
  return Track;
}
export function getRoomEvent(): typeof RoomEvent {
  return RoomEvent;
}
export function getDisconnectReason(): typeof DisconnectReason {
  return DisconnectReason;
}

export function isLocalVideoTrack(track: LiveKitTrack | undefined): track is LocalVideoTrack {
  return track instanceof LocalVideoTrack;
}

// ↔ نظير `switchCamera` بتاعة native.tsx — على الويب `restartTrack` مع
// قيد facingMode هو المسار القياسي المدعوم من livekit-client نفسها
// (بيستخدم getUserMedia بمتصفح حقيقي)، وهو شغال بالفعل، فمفيش داعي
// لتغييره هنا. الفرق مقصود بين المنصتين، مش تكرار كود ناقص.
export async function switchCamera(
  track: LocalVideoTrack,
  nextFacingMode: "user" | "environment"
): Promise<void> {
  await track.restartTrack({ facingMode: nextFacingMode });
}

export function registerGlobals(): void {
  // Web LiveKit does not need native global registration.
}

export const LiveKitRoom = ComponentsLiveKitRoom;

type VideoTrackProps = {
  trackRef: TrackReference | undefined;
  style?: StyleProp<ViewStyle>;
};

export const VideoTrack: ComponentType<VideoTrackProps> = ({ trackRef, style }) => {
  if (!trackRef) return <View style={style} />;
  return <ComponentsVideoTrack trackRef={trackRef} style={style as CSSProperties} />;
};

export const AudioSession = {
  startAudioSession: (): void => undefined,
  stopAudioSession: (): void => undefined,
};
