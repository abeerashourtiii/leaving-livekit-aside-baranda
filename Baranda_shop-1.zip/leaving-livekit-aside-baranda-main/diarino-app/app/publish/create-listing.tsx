import { useEffect, useRef, useState } from "react";
import { KeyboardAvoid } from "../../components/shared/KeyboardAvoid";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router, useLocalSearchParams } from "expo-router";
import {
  View, Text, ScrollView, Pressable, StyleSheet, Alert, ActivityIndicator,
} from "react-native";
import { Image } from "expo-image";
import * as ImagePicker from "expo-image-picker";
import * as VideoThumbnails from "expo-video-thumbnails";
import * as Location from "expo-location";
import Svg, { Path } from "react-native-svg";
import { FormLabel, FormError, FormInput, ChipRow, MultiChipRow, HelpBox } from "../../components/publish/FormControls";
import { ProvinceAutocomplete } from "../../components/publish/ProvinceAutocomplete";
import { SocialShareSection } from "../../components/publish/SocialShareSection";
import { PhoneInput, PhoneInputValue } from "../../components/shared/PhoneInput";
import { SocialPlatform } from "../../lib/hooks/useSocialShareLinks";
import { MediaItem, Purpose } from "../../lib/types";
import { usePropertyById, useCreateProperty, useUpdateProperty, useMyProperties } from "../../lib/hooks/useProperties";
import { useCurrentUser } from "../../lib/hooks/useCurrentUser";
import { useLanguage } from "../../lib/hooks/useLanguage";
import { useDealSettings } from "../../lib/hooks/useDeals";
import { supabase } from "../../lib/supabase";
import { uploadToCloudinary } from "../../lib/cloudinary";
import { useMusicLibrary, resolveMusicSource } from "../../lib/musicLibrary";
import { startMusicPreview, stopMusicPreview } from "../../lib/musicPlayer";
import { compressVideoForUpload, willCompressVideo, clearCompressedVideoCache, VideoMeta } from "../../lib/videoCompress";
import { acquireKeepAwake, releaseKeepAwake } from "../../lib/keepAwake";
import { UploadProgressModal, UploadPhase } from "../../components/publish/UploadProgressModal";
import { showToast } from "../../components/shared/Toast";
import { validateAndFormatPhone, splitE164 } from "../../lib/phone";
import { findCountry } from "../../lib/countries";
import { useLogMedia } from "../../lib/hooks/useMedia";
import { useDraftById, useDraftMutations } from "../../lib/hooks/useDrafts";
import { useThemeColors, ThemeColors } from "../../lib/hooks/useThemeColors";
import { signOut } from "../../lib/hooks/useAuth";

const TYPES = ["شقة", "فيلا", "بنتهاوس", "تاون هاوس", "تجاري", "إداري", "طبي", "أرض"];
const FINISH_TYPES = ["بدون تشطيب", "نصف تشطيب", "تشطيب كامل", "لوكس", "سوبر لوكس", "الترا لوكس"];
const FEATURES = [
  "حديقة", "جراج", "أمن وحراسة", "مطبخ مجهز", "مصعد", "حمام سباحة", "تراس",
  "مفروش", "مكيف", "خط أرضي", "عداد كهرباء", "عداد مياه", "عداد غاز طبيعي",
];
// ↔ حدود الفيديو (قرار المنتج): 300 ثانية (٥ دقائق) كحد أقصى للمدة، و600MB كحد أقصى
// للحجم قبل الرفع (أندرويد/آيفون). ⚠ لازم يكون سقف فيديو خطة Cloudinary عندك
// (وسقف الطلب الواحد فى الـ upload API) >= الرقم ده، وإلا الرفع هيفشل من
// Cloudinary بعد وقت الرفع — لو حصل ده قلّل الثابت أو انقل الرفع لـ chunked
// upload (شوف docs/video-pipeline.md). أي فيديو بيعدّي عبر الـ Incoming
// transformation على الـ preset (720p H.264) فالحجم الفعلي بعد الرفع أصغر بكتير.
// ↔ مسارا الوسائط (يختار المستخدم واحد منهم): فيديو (+ غلاف اختياري/لقطة عشوائية) أو حتى MAX_PHOTOS صورة بتتعرض فى
// الريل تلقائيًا بشكل تتابعى (slideshow) مع صورة رئيسية هى واجهة كارت الريل وأول صورة فى العرض.
const MAX_PHOTOS = 15;
const MAX_VIDEO_SEC = 5 * 60;
const MAX_VIDEO_BYTES = 600 * 1024 * 1024;

export default function CreateListingScreen() {
  const { user } = useCurrentUser();
  const { t } = useLanguage();
  const { editId, draftId } = useLocalSearchParams<{ editId?: string; draftId?: string }>();
  // ↔ الإعلان المراد تعديله بييجى من «إعلاناتي» (useMyProperties) الأول — قبل كده كان
  // من قائمة عامة محدودة (300 إعلان) فإعلان قديم/غير معتمد ممكن ما يلاقيهوش
  // وشاشة التعديل تفتح فاضية.
  const { data: myAdsForEdit } = useMyProperties(editId ? user?.id : undefined);
  const editingFallback = usePropertyById(editId);
  const editingAd = (editId ? myAdsForEdit?.find((p) => p.id === editId) : undefined) ?? editingFallback;
  const { data: draft } = useDraftById(draftId);
  const { save: saveDraft, remove: removeDraft } = useDraftMutations();
  const createProperty = useCreateProperty();
  const updateProperty = useUpdateProperty();
  const logMedia = useLogMedia();
  const [submitting, setSubmitting] = useState(false);
  const [savingDraft, setSavingDraft] = useState(false);
  const insets = useSafeAreaInsets();
  const themeColors = useThemeColors();
  const styles = createStyles(themeColors);

  // معرف المسودة الحالي (يتحدث إذا قمنا بحفظ مسودة جديدة أثناء التتواجد بالشاشة)
  const [currentDraftId, setCurrentDraftId] = useState<string | undefined>(draftId);

  const [purpose, setPurpose] = useState<Purpose | "">("");
  const [type, setType] = useState("");
  const [province, setProvince] = useState("");
  const [location, setLocation] = useState("");
  const [price, setPrice] = useState("");
  const [area, setArea] = useState("");
  const [rooms, setRooms] = useState("");
  const [baths, setBaths] = useState("");
  const [reception, setReception] = useState("");
  const [floor, setFloor] = useState("");
  const [payment, setPayment] = useState<"cash" | "installment" | "">("");
  const [negotiable, setNegotiable] = useState<"yes" | "no" | "">("");
  const [features, setFeatures] = useState<Set<string>>(new Set());
  const [finishType, setFinishType] = useState("");
  const [finishTypeOpen, setFinishTypeOpen] = useState(false);
  const [status, setStatus] = useState<"ready" | "building" | "">("");
  const [deliveryDate, setDeliveryDate] = useState("");
  const [shortTitle, setShortTitle] = useState("");
  const [description, setDescription] = useState("");
  const [videoItem, setVideoItem] = useState<MediaItem | null>(null);
  const [videoDurationMs, setVideoDurationMs] = useState<number | null>(null);
  // بيانات الفيديو من الـ picker (أبعاد/مدة/حجم) — بنقرر منها هل نضغط الفيديو قبل الرفع (أندرويد).
  const [videoMeta, setVideoMeta] = useState<VideoMeta | null>(null);
  // حالة مؤشر الضغط/الرفع (null = مفيش عملية شغالة).
  const [uploadUi, setUploadUi] = useState<{ phase: UploadPhase; value: number; withCompression: boolean } | null>(null);
  const [coverItem, setCoverItem] = useState<MediaItem | null>(null);
  const [mediaMode, setMediaMode] = useState<"video" | "photos">("video");
  const [photoItems, setPhotoItems] = useState<MediaItem[]>([]);
  const [mainPhotoUrl, setMainPhotoUrl] = useState<string | null>(null);
  const [music, setMusic] = useState("");
  // ↔ مكتبة الموسيقى مخفية لحد ما المستخدم يضغط عليها، وكل مقطع له زر معاينة (▶) قبل الاختيار.
  const { tracks: musicTracks } = useMusicLibrary();
  const [musicOpen, setMusicOpen] = useState(false);
  const [previewingTitle, setPreviewingTitle] = useState<string | null>(null);
  const [phone, setPhone] = useState<PhoneInputValue>({ countryIso2: "", localNumber: "" });
  const [sharePlatforms, setSharePlatforms] = useState<Set<SocialPlatform>>(new Set());
  const [errors, setErrors] = useState<Set<string>>(new Set());
  // ↔ إقرار ملكية حقوق الوسائط (سياسة حقوق النشر / نشر الصور والفيديو) — إلزامى عند نشر إعلان جديد وعند تعديل إعلان قائم، ووقته بيتسجّل فى properties.rights_declared_at.
  const [rightsAccepted, setRightsAccepted] = useState(false);
  const { settings: dealSettings } = useDealSettings();
  const scrollRef = useRef<ScrollView>(null);

  // وقف معاينة الموسيقى عند الخروج من الصفحة.
  useEffect(() => () => { void stopMusicPreview(); }, []);

  async function togglePreview(title: string) {
    if (previewingTitle === title) {
      await stopMusicPreview();
      setPreviewingTitle(null);
      return;
    }
    const source = resolveMusicSource(title, musicTracks);
    if (!source) return;
    setPreviewingTitle(title);
    const ok = await startMusicPreview(source, () => setPreviewingTitle((cur) => (cur === title ? null : cur)));
    if (!ok) {
      setPreviewingTitle((cur) => (cur === title ? null : cur));
      showToast(t("تعذر تشغيل المقطع الموسيقي."));
    }
  }

  function toggleMusicOpen() {
    if (musicOpen) {
      void stopMusicPreview();
      setPreviewingTitle(null);
    }
    setMusicOpen((o) => !o);
  }

  // تحميل بيانات الإعلان عند التعديل
  useEffect(() => {
    if (!editingAd) return;
    setPurpose(editingAd.purpose);
    setType(editingAd.type);
    setProvince(editingAd.province);
    setLocation(editingAd.location);
    setPrice(String(editingAd.price));
    setArea(String(editingAd.area));
    setRooms(String(editingAd.rooms));
    setBaths(String(editingAd.baths));
    setReception(String(editingAd.reception));
    setFeatures(new Set(editingAd.features));
    setFinishType(editingAd.finishType || "");
    setStatus(editingAd.status || "");
    setDeliveryDate(editingAd.deliveryDate || "");
    setFloor(editingAd.floor != null ? String(editingAd.floor) : "");
    setPayment(editingAd.payment || "");
    setNegotiable(editingAd.negotiable === undefined ? "" : editingAd.negotiable ? "yes" : "no");
    setShortTitle(editingAd.shortTitle || editingAd.title);
    setDescription(editingAd.description);
    const editVideo = editingAd.media.find((m) => m.type === "video") ?? null;
    const editImages = editingAd.media.filter((m) => m.type === "image");
    setVideoItem(editVideo);
    setCoverItem(editImages[0] ?? null);
    if (!editVideo && editImages.length > 0) {
      // ↔ إعلان بالصور: نرجّع مسار الصور بنفس الترتيب والصورة الرئيسية (الغلاف المحفوظ).
      setMediaMode("photos");
      setPhotoItems(editImages.slice(0, MAX_PHOTOS));
      setMainPhotoUrl(editingAd.coverImage && editImages.some((m) => m.url === editingAd.coverImage) ? editingAd.coverImage : editImages[0].url);
    }
    setMusic(editingAd.music || "");
    const split = editingAd.seller.phone ? splitE164(editingAd.seller.phone) : null;
    setPhone(split ? { countryIso2: split.countryIso2, localNumber: split.localNumber } : { countryIso2: "", localNumber: "" });
    setSharePlatforms(new Set((editingAd.sharePlatforms || []) as SocialPlatform[]));
  }, [editingAd?.id]);

  // تحميل بيانات المسودة
  useEffect(() => {
    if (!draft) return;
    const d = draft.data as Record<string, any>;
    if (d.purpose !== undefined) setPurpose(d.purpose);
    if (d.type !== undefined) setType(d.type);
    if (d.province !== undefined) setProvince(d.province);
    if (d.location !== undefined) setLocation(d.location);
    if (d.price !== undefined) setPrice(d.price);
    if (d.area !== undefined) setArea(d.area);
    if (d.rooms !== undefined) setRooms(d.rooms);
    if (d.baths !== undefined) setBaths(d.baths);
    if (d.reception !== undefined) setReception(d.reception);
    if (d.floor !== undefined) setFloor(d.floor);
    if (d.payment !== undefined) setPayment(d.payment);
    if (d.negotiable !== undefined) setNegotiable(d.negotiable);
    if (d.features && Array.isArray(d.features)) setFeatures(new Set(d.features));
    if (d.finishType !== undefined) setFinishType(d.finishType);
    if (d.status !== undefined) setStatus(d.status);
    if (d.deliveryDate !== undefined) setDeliveryDate(d.deliveryDate);
    if (d.shortTitle !== undefined) setShortTitle(d.shortTitle);
    if (d.description !== undefined) setDescription(d.description);
    if (d.videoItem !== undefined) setVideoItem(d.videoItem);
    if (d.coverItem !== undefined) setCoverItem(d.coverItem);
    if (d.mediaMode === "video" || d.mediaMode === "photos") setMediaMode(d.mediaMode);
    if (Array.isArray(d.photoItems)) setPhotoItems(d.photoItems.slice(0, MAX_PHOTOS));
    if (d.mainPhotoUrl !== undefined) setMainPhotoUrl(d.mainPhotoUrl);
    if (d.music !== undefined) setMusic(d.music);
    if (d.phone !== undefined) setPhone(d.phone);
    if (d.sharePlatforms && Array.isArray(d.sharePlatforms)) setSharePlatforms(new Set(d.sharePlatforms));
    setCurrentDraftId(draft.id);
  }, [draft?.id]);

  function currentFormAsDraftData() {
    return {
      purpose, type, province, location, price, area, rooms, baths, reception, floor,
      payment, negotiable, features: Array.from(features), finishType, status, deliveryDate,
      shortTitle, description, videoItem, coverItem, mediaMode, photoItems, mainPhotoUrl, music, phone, sharePlatforms: Array.from(sharePlatforms),
    };
  }

  async function handleSaveDraft() {
    setSavingDraft(true);
    try {
      const savedId = await saveDraft.mutateAsync({
        id: currentDraftId,
        draftType: "listing",
        title: shortTitle.trim() || null,
        data: currentFormAsDraftData(),
      });
      setCurrentDraftId(savedId);
      Alert.alert(t("تم الحفظ"), t("اتحفظت المسودة، تقدر تكمل تعديلها في أي وقت من صفحة حسابي."));
      router.back();
    } catch (err) {
      Alert.alert(t("حدث خطأ"), t("تعذر حفظ المسودة، حاول مرة أخرى."));
    } finally {
      setSavingDraft(false);
    }
  }

  function onShortTitleChange(v: string) {
    const words = v.split(/\s+/).filter(Boolean);
    if (words.length > 7) return;
    setShortTitle(v);
  }

  function toggleSharePlatform(platform: SocialPlatform) {
    setSharePlatforms((prev) => {
      const next = new Set(prev);
      next.has(platform) ? next.delete(platform) : next.add(platform);
      return next;
    });
  }

  async function pickVideo() {
    // ↔ ضغط الفيديو قبل الرفع: `quality` بيأثر على الصور بس (مش الفيديو)،
    // فقبل كده الفيديو كان بيترفع بحجمه الأصلي من الكاميرا (ممكن 1080p/4K
    // بعشرات الميجابت/ثانية). videoExportPreset بيعيد ترميز الفيديو على iOS
    // لـ H.264 بدقة 720p وقت الاختيار — أصغر بكتير وبيبدأ تشغيله أسرع فى
    // الريلز. أندرويد والويب مالهمش نظير فى الـ picker (الخيار بيتجاهل)،
    // فضغطهم لازم يتم من إعدادات الـ upload preset على Cloudinary أو بمكتبة
    // ضغط أصلية — شوف docs/video-pipeline.md.
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Videos,
      videoExportPreset: ImagePicker.VideoExportPreset.H264_1280x720,
    });
    if (result.canceled || !result.assets[0]) return;
    const asset = result.assets[0];
    if (asset.duration && asset.duration / 1000 > MAX_VIDEO_SEC) {
      Alert.alert(t("الفيديو طويل جدًا"), t("الحد الأقصى لمدة الفيديو ٥ دقائق."));
      return;
    }
    // fileSize بيرجع على أندرويد/آيفون؛ على الويب ممكن يبقى undefined فبنتخطى الفحص.
    if (typeof asset.fileSize === "number" && asset.fileSize > MAX_VIDEO_BYTES) {
      Alert.alert(t("الفيديو كبير جدًا"), t("الحد الأقصى لحجم الفيديو ٦٠٠ ميجابايت. اختر فيديو أصغر أو أقصر."));
      return;
    }
    setVideoItem({ type: "video", url: asset.uri });
    setVideoDurationMs(asset.duration ?? null);
    setVideoMeta({ width: asset.width, height: asset.height, durationMs: asset.duration ?? null, fileSize: asset.fileSize ?? null });
  }

  async function pickCoverImage() {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.8,
    });
    if (result.canceled || !result.assets[0]) return;
    setCoverItem({ type: "image", url: result.assets[0].uri });
  }

  // ↔ اختيار صور الإعلان (حتى MAX_PHOTOS): اختيار متعدد من المعرض (أندرويد/آيفون/الويب). الزيادة عن الحد بتتقصّ مع تنبيه.
  async function pickPhotos() {
    const remaining = MAX_PHOTOS - photoItems.length;
    if (remaining <= 0) {
      showToast(t("وصلت للحد الأقصى: ١٥ صورة."));
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsMultipleSelection: true,
      selectionLimit: remaining,
      quality: 0.8,
    });
    if (result.canceled || result.assets.length === 0) return;
    const existing = new Set(photoItems.map((p) => p.url));
    const fresh = result.assets.filter((a) => !existing.has(a.uri)).map<MediaItem>((a) => ({ type: "image", url: a.uri }));
    const accepted = fresh.slice(0, remaining);
    if (fresh.length > remaining) showToast(t("الحد الأقصى ١٥ صورة، تمت إضافة الصور المتاحة فقط."));
    if (accepted.length === 0) return;
    setPhotoItems((prev) => [...prev, ...accepted]);
    setMainPhotoUrl((prev) => prev ?? accepted[0].url);
    setErrors((e) => { const n = new Set(e); n.delete("media"); return n; });
  }

  function removePhoto(url: string) {
    const next = photoItems.filter((p) => p.url !== url);
    setPhotoItems(next);
    if (mainPhotoUrl === url) setMainPhotoUrl(next[0]?.url ?? null);
  }

  async function generateCoverFromVideo(videoUri: string): Promise<MediaItem | null> {
    try {
      const duration = videoDurationMs && videoDurationMs > 0 ? videoDurationMs : 6000;
      const randomTimeMs = Math.floor(duration * 0.1 + Math.random() * duration * 0.7);
      const { uri } = await VideoThumbnails.getThumbnailAsync(videoUri, { time: randomTimeMs, quality: 0.8 });
      return { type: "image", url: uri };
    } catch (err) {
      console.warn("Failed to generate a cover frame from the video:", err);
      return null;
    }
  }

  // ↔ رفع الوسائط المحلية. الفيديو: (أندرويد) ضغط محلي لـ 720p ← رفع بتقدّم فعلي.
  // الصور: رفع عادي (صغيرة). كل خطوة بتحدّث مؤشر التقدّم (uploadUi) عشان المستخدم
  // يشوف حالة الضغط والرفع ومايقفلش التطبيق. أي فشل فى الضغط بيرجع للملف الأصلي.
  function setPhaseProgress(phase: UploadPhase, value: number, withCompression: boolean) {
    setUploadUi((prev) =>
      prev && prev.phase === phase && prev.withCompression === withCompression && Math.abs(prev.value - value) < 0.01 && value < 1
        ? prev
        : { phase, value, withCompression }
    );
  }

  async function uploadLocalMedia(sellerId: string, items: MediaItem[], withCompression: boolean): Promise<MediaItem[]> {
    const uploaded: MediaItem[] = [];
    for (const item of items) {
      if (/^https?:\/\//.test(item.url)) {
        uploaded.push(item);
        continue;
      }
      let uri = item.url;
      if (item.type === "video" && withCompression) {
        setPhaseProgress("compress", 0, true);
        const compressed = await compressVideoForUpload(uri, videoMeta ?? {}, (p) => setPhaseProgress("compress", p, true));
        if (compressed.failed) showToast(t("تعذر ضغط الفيديو، سيتم رفعه بحجمه الأصلي."));
        uri = compressed.uri;
      }
      if (item.type === "video") setPhaseProgress("upload", 0, withCompression); // الصور (الغلاف) صغيرة: مبنصفّرش المؤشر
      const result = await uploadToCloudinary(
        uri,
        item.type,
        item.type === "video" ? (p) => setPhaseProgress("upload", p, withCompression) : undefined
      );
      logMedia.mutate({ ownerId: sellerId, type: item.type, context: "property", result });
      uploaded.push({ type: item.type, url: result.url });
    }
    return uploaded;
  }

  // ↔ رفع صور الإعلان: 3 فى نفس الوقت (بنفس ترتيب القائمة، الرئيسية أولًا) مع مؤشر تقدّم بعدد الصور المرفوعة.
  async function uploadPhotos(sellerId: string, items: MediaItem[]): Promise<MediaItem[]> {
    const out: MediaItem[] = new Array(items.length);
    let done = 0;
    const CONCURRENCY = 3;
    for (let i = 0; i < items.length; i += CONCURRENCY) {
      await Promise.all(
        items.slice(i, i + CONCURRENCY).map(async (item, k) => {
          if (/^https?:\/\//.test(item.url)) {
            out[i + k] = item;
          } else {
            const result = await uploadToCloudinary(item.url, "image");
            logMedia.mutate({ ownerId: sellerId, type: "image", context: "property", result });
            out[i + k] = { type: "image", url: result.url };
          }
          done += 1;
          setPhaseProgress("upload", done / items.length, false);
        })
      );
    }
    return out;
  }

  const FIELD_LABELS: Record<string, string> = {
    purpose: "الغرض (بيع/إيجار)", type: "نوع العقار", province: "المحافظة", location: "المنطقة",
    price: "السعر", area: "المساحة", rooms: "عدد الغرف", baths: "عدد الحمامات", reception: "الريسبشن",
    floor: "الدور", payment: "طريقة الدفع", negotiable: "قابل للتفاوض", status: "حالة العقار",
    shortTitle: "العنوان المختصر", description: "الوصف", media: mediaMode === "video" ? "فيديو العقار" : "صور العقار", music: "موسيقى الإعلان", phone: "رقم الهاتف", rights: "إقرار ملكية الحقوق",
  };

  function validate(): boolean {
    const errs = new Set<string>();
    if (!purpose) errs.add("purpose");
    if (!type) errs.add("type");
    if (!province) errs.add("province");
    if (!location.trim()) errs.add("location");
    if (!price || isNaN(Number(price)) || Number(price) <= 0) errs.add("price");
    if (!area || isNaN(Number(area)) || Number(area) <= 0) errs.add("area");
    if (rooms === "" || isNaN(Number(rooms))) errs.add("rooms");
    if (baths === "" || isNaN(Number(baths))) errs.add("baths");
    if (reception === "" || isNaN(Number(reception))) errs.add("reception");
    if (floor === "" || isNaN(Number(floor))) errs.add("floor");
    if (!payment) errs.add("payment");
    if (!negotiable) errs.add("negotiable");
    if (!status) errs.add("status");
    if (!shortTitle.trim()) errs.add("shortTitle");
    if (!description.trim()) errs.add("description");
    if (mediaMode === "video" ? !videoItem : photoItems.length === 0) errs.add("media");
    if (!phone.countryIso2 || !validateAndFormatPhone(phone.localNumber, phone.countryIso2).valid) errs.add("phone");
    if (!rightsAccepted) errs.add("rights");
    setErrors(errs);
    if (errs.size > 0) {
      scrollRef.current?.scrollTo({ y: 0, animated: true });
      const missing = Array.from(errs).map((k) => FIELD_LABELS[k] || k).join("، ");
      Alert.alert(t("أكمل البيانات الناقصة"), missing);
    }
    return errs.size === 0;
  }

  async function submit() {
    if (!validate()) return;
    if (mediaMode === "video" && !videoItem) return;
    if (!user) return;

    setSubmitting(true);
    acquireKeepAwake(); // الشاشة ماتنطفيش أثناء الضغط/الرفع الطويل
    try {
      let uploadedMedia: MediaItem[];
      if (mediaMode === "video" && videoItem) {
        const cover = coverItem ?? (await generateCoverFromVideo(videoItem.url));
        const rawMedia: MediaItem[] = [
          videoItem,
          ...(cover ? [cover] : []),
        ];
        // مرحلة "ضغط الفيديو" بتظهر فى المؤشر بس لو هتحصل فعلًا (أندرويد + فيديو محتاج ضغط).
        const withCompression = !/^https?:\/\//.test(videoItem.url) && willCompressVideo(videoMeta ?? {});
        setPhaseProgress(withCompression ? "compress" : "upload", 0, withCompression);
        uploadedMedia = await uploadLocalMedia(user.id, rawMedia, withCompression);
        setUploadUi((prev) => ({ phase: "publish", value: 1, withCompression: prev?.withCompression ?? withCompression }));
      } else {
        // ↔ مسار الصور: الرئيسية أولًا (هى coverImage وواجهة الكارت وأول صورة فى عرض الريل)، وباقى الصور بترتيب اختيارها.
        const main = photoItems.find((p) => p.url === mainPhotoUrl) ?? photoItems[0];
        const ordered = [main, ...photoItems.filter((p) => p !== main)];
        setPhaseProgress("upload", 0, false);
        uploadedMedia = await uploadPhotos(user.id, ordered);
        setUploadUi({ phase: "publish", value: 1, withCompression: false });
      }

      let lat: number | undefined;
      let lng: number | undefined;
      try {
        let perm = await Location.getForegroundPermissionsAsync();
        if (!perm.granted && perm.canAskAgain) {
          perm = await Location.requestForegroundPermissionsAsync();
        }
        if (perm.granted) {
          const results = await Location.geocodeAsync(`${location.trim()}, ${province}, مصر`);
          if (results[0]) {
            lat = results[0].latitude;
            lng = results[0].longitude;
          }
        }
      } catch (err) {
        console.warn("Failed to geocode listing address:", err);
      }

      const adFields = {
        purpose: purpose as Purpose,
        type,
        title: shortTitle.trim(),
        shortTitle: shortTitle.trim(),
        province,
        location: location.trim(),
        lat, lng,
        price: Number(price),
        area: Number(area),
        rooms: Number(rooms),
        baths: Number(baths),
        reception: Number(reception),
        floor: Number(floor),
        payment: payment as "cash" | "installment",
        negotiable: negotiable === "yes",
        finishType: finishType.trim() || undefined,
        status: status as "ready" | "building",
        deliveryDate: status === "building" ? deliveryDate.trim() || undefined : undefined,
        features: Array.from(features),
        description: description.trim(),
        media: uploadedMedia,
        coverImage: uploadedMedia.find((m) => m.type === "image")?.url ?? null,
        music: music || null,
        sharePlatforms: Array.from(sharePlatforms),
      };

      if (phone.localNumber.trim() && phone.countryIso2) {
        const result = validateAndFormatPhone(phone.localNumber, phone.countryIso2);
        if (result.valid) {
          const country = findCountry(phone.countryIso2);
          const { error } = await supabase.from("profiles").upsert({
            id: user.id,
            phone_e164: result.e164,
            phone_country_code: country?.callingCode ?? null,
            phone_country_name: country?.nameAr ?? null,
          }, { onConflict: "id" });
          if (error) throw error;
        }
      }

      // ↔ الإعلان ممكن يتحط «قيد المراجعة» (الموافقة المسبقة من الأدمن مفعَّلة): نعرف ده من الصف اللى رجع من الخادم ونقول للمعلن.
      let underReview = false;
      if (editingAd) {
        const res = await updateProperty.mutateAsync({ id: editingAd.id, patch: { ...adFields, rightsDeclaredAt: new Date().toISOString() } });
        underReview = res.moderationStatus === "pending" && editingAd.moderationStatus !== "pending";
      } else {
        const created = await createProperty.mutateAsync({ ...adFields, sellerId: user.id, rightsDeclaredAt: new Date().toISOString() });
        underReview = (created as { moderation_status?: string }).moderation_status === "pending";
      }
      if (underReview) {
        showToast(t("تم استلام إعلانك وهو قيد المراجعة. سيظهر للجميع بعد موافقة الإدارة وسنُشعرك بالقرار."));
      }

      // حذف المسودة إن وجدت فور النجاح في النشر
      if (currentDraftId) {
        removeDraft.mutate(currentDraftId);
      }

      router.replace("/(tabs)/account?tab=ads");
    } catch (err) {
      console.warn("Publish listing failed:", err);
      // ↔ انتهت نافذة الـ 24 ساعة من النشر: الخادم رفض التعديل (migration 20261021000000).
      if (String((err as { message?: string })?.message ?? "").includes("edit_window_closed")) {
        showToast(t("انتهت مدة التعديل (24 ساعة من نشر الإعلان)"));
        return;
      }
      // Alert.alert مبيظهرش على الويب — Toast بيشتغل على كل المنصات.
      showToast(`${t("تعذر نشر الإعلان")} — ${t("حاول مرة أخرى.")}`);
    } finally {
      releaseKeepAwake();
      clearCompressedVideoCache();
      setUploadUi(null);
      setSubmitting(false);
    }
  }

  if (!user) {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <Pressable style={styles.closeBtn} onPress={() => router.back()} hitSlop={8}>
            <Svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={themeColors.text} strokeWidth={2}><Path d="M18 6L6 18M6 6l12 12" /></Svg>
          </Pressable>
          <Text style={styles.headerTitle}>{t("انشر عقارك")}</Text>
          <View style={{ width: 34 }} />
        </View>
        <View style={styles.authRequiredBox}>
          <Text style={styles.authRequiredTitle}>{t("يجب تسجيل الدخول لنشر إعلان")}</Text>
          <Text style={styles.authRequiredSubtitle}>{t("سجّل الدخول من أجل مشاركة الإعلان مع المشترين والبائعين.")}</Text>
          <Pressable style={styles.authRequiredBtn} onPress={async () => { await signOut(); router.replace("/"); }}>
            <Text style={styles.authRequiredBtnText}>{t("تسجيل الدخول")}</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  return (
    <KeyboardAvoid style={styles.container} iosPadding={false}>
      <View style={styles.header}>
        <Pressable style={styles.closeBtn} onPress={() => router.back()} hitSlop={8}>
          <Svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke={themeColors.text} strokeWidth={2}><Path d="M18 6L6 18M6 6l12 12" /></Svg>
        </Pressable>
        <Text style={styles.headerTitle}>{editingAd ? t("تعديل الإعلان") : t("انشر عقارك")}</Text>
        <View style={{ width: 34 }} />
      </View>

      <ScrollView ref={scrollRef} keyboardShouldPersistTaps="handled" automaticallyAdjustKeyboardInsets contentContainerStyle={{ padding: 16, paddingBottom: 30 }} showsVerticalScrollIndicator={false}>
        <HelpBox title="🎥 وسائط الإعلان">
          اختر أحد مسارين لعرض إعلانك في الريلز: تحميل فيديو (حتى ٥ دقائق، مع صورة غلاف اختيارية أو لقطة عشوائية منه)، أو تحميل حتى ١٥ صورة تُعرض تلقائيًا بشكل تتابعي مع صورة رئيسية تكون واجهة الكارت في صفحة المعلن والبحث وإدارة الحساب.
        </HelpBox>

        <FormLabel text="الغرض من الإعلان" required />
        <ChipRow options={["sale", "rent"]} value={purpose} onChange={setPurpose} labels={{ sale: "للبيع", rent: "للإيجار" }} />
        <FormError text="من فضلك اختر الغرض" show={errors.has("purpose")} />

        <FormLabel text="نوع العقار" required />
        <ChipRow options={TYPES} value={type} onChange={setType} />
        <FormError text="من فضلك اختر نوع العقار" show={errors.has("type")} />

        <FormLabel text="المحافظة" required />
        <ProvinceAutocomplete value={province} onChange={setProvince} error={errors.has("province")} />
        <FormError text="من فضلك اختر المحافظة" show={errors.has("province")} />

        <FormLabel text="المنطقة / الحي / الكمبوند" required />
        <FormInput value={location} onChangeText={setLocation} placeholder="مثال: الشيخ زايد، كمبوند بالم هيلز ..." error={errors.has("location")} />
        <FormError text="من فضلك أدخل المنطقة" show={errors.has("location")} />

        <View style={styles.row2}>
          <View style={{ flex: 1 }}>
            <FormLabel text="السعر (ج.م)" required />
            <FormInput value={price} onChangeText={setPrice} placeholder="3500000" keyboardType="number-pad" error={errors.has("price")} />
            <FormError text="من فضلك أدخل السعر" show={errors.has("price")} />
          </View>
          <View style={{ flex: 1 }}>
            <FormLabel text="المساحة (م²)" required />
            <FormInput value={area} onChangeText={setArea} placeholder="180" keyboardType="number-pad" error={errors.has("area")} />
            <FormError text="من فضلك أدخل المساحة" show={errors.has("area")} />
          </View>
        </View>

        <View style={styles.row2}>
          <View style={{ flex: 1 }}>
            <FormLabel text="عدد الغرف" required />
            <FormInput value={rooms} onChangeText={setRooms} placeholder="3" keyboardType="number-pad" error={errors.has("rooms")} />
          </View>
          <View style={{ flex: 1 }}>
            <FormLabel text="عدد الحمامات" required />
            <FormInput value={baths} onChangeText={setBaths} placeholder="2" keyboardType="number-pad" error={errors.has("baths")} />
          </View>
        </View>

        <View style={styles.row2}>
          <View style={{ flex: 1 }}>
            <FormLabel text="الريسبشن" required />
            <FormInput value={reception} onChangeText={setReception} placeholder="2" keyboardType="number-pad" error={errors.has("reception")} />
          </View>
          <View style={{ flex: 1 }}>
            <FormLabel text="رقم الطابق" required />
            <FormInput value={floor} onChangeText={setFloor} placeholder="3" keyboardType="number-pad" error={errors.has("floor")} />
          </View>
        </View>
        <Text style={styles.hint}>💡 رقم الطابق (0 = أرضي)</Text>

        <FormLabel text="طريقة الدفع" required />
        <ChipRow options={["cash", "installment"]} value={payment} onChange={setPayment} labels={{ cash: "كاش", installment: "قسط" }} />
        <FormError text="من فضلك اختر طريقة الدفع" show={errors.has("payment")} />

        <FormLabel text="السعر قابل للتفاوض" required />
        <ChipRow options={["yes", "no"]} value={negotiable} onChange={setNegotiable} labels={{ yes: "نعم", no: "لا" }} />
        <FormError text="من فضلك اختر" show={errors.has("negotiable")} />

        <FormLabel text="الكماليات والمرافق" />
        <MultiChipRow
          options={FEATURES.map((f) => ({ key: f, label: f }))}
          values={features}
          onToggle={(k) => setFeatures((prev) => { const next = new Set(prev); next.has(k) ? next.delete(k) : next.add(k); return next; })}
        />

        <FormLabel text="نوع التشطيب" optional />
        <Pressable
          style={styles.finishSelector}
          onPress={() => setFinishTypeOpen((open) => !open)}
        >
          <Text style={finishType ? styles.finishSelectorText : styles.finishSelectorPlaceholder}>
            {finishType || t("اختر نوع التشطيب")}
          </Text>
        </Pressable>
        {finishTypeOpen && (
          <View style={styles.finishOptions}>
            {FINISH_TYPES.map((option) => (
              <Pressable
                key={option}
                style={[styles.finishOption, finishType === option && styles.finishOptionActive]}
                onPress={() => { setFinishType(option); setFinishTypeOpen(false); }}
              >
                <Text style={finishType === option ? styles.finishOptionActiveText : styles.finishOptionText}>
                  {t(option)}
                </Text>
              </Pressable>
            ))}
          </View>
        )}

        <FormLabel text="حالة العقار" required />
        <ChipRow options={["ready", "building"]} value={status} onChange={setStatus} labels={{ ready: "جاهز للتسليم", building: "قيد الإنشاء" }} />
        <FormError text="من فضلك اختر حالة العقار" show={errors.has("status")} />

        {status === "building" && (
          <>
            <FormLabel text="تاريخ التسليم المتوقع" optional />
            <FormInput value={deliveryDate} onChangeText={setDeliveryDate} placeholder="2027-06-30" />
          </>
        )}

        <FormLabel text="عنوان الإعلان (بحد أقصى 7 كلمات)" required />
        <FormInput value={shortTitle} onChangeText={onShortTitleChange} placeholder="مثال: شقة فاخرة بموقع مميز" maxLength={80} error={errors.has("shortTitle")} />
        <FormError text="أدخل عنوان مختصر (حتى 7 كلمات)" show={errors.has("shortTitle")} />

        <FormLabel text="الوصف" required />
        <FormInput value={description} onChangeText={setDescription} placeholder="اكتب وصف تفصيلي ..." multiline numberOfLines={4} style={{ minHeight: 90, textAlignVertical: "top" }} error={errors.has("description")} />
        <FormError text="من فضلك أدخل الوصف" show={errors.has("description")} />

        <SocialShareSection selected={sharePlatforms} onToggle={toggleSharePlatform} />

        <FormLabel text={t("وسائط الإعلان")} required />
        <ChipRow
          options={["video", "photos"] as const}
          value={mediaMode}
          onChange={(v) => { setMediaMode(v); setErrors((e) => { const n = new Set(e); n.delete("media"); return n; }); }}
          labels={{ video: "🎬 فيديو", photos: "🖼️ صور (حتى ١٥)" }}
        />

        {mediaMode === "video" ? (
          <>
            <FormLabel text={t("فيديو العقار (مطلوب، حتى ٥ دقائق)")} required />
            <View style={styles.mediaGrid}>
              {videoItem ? (
                <View style={styles.mediaCell}>
                  <View style={[StyleSheet.absoluteFill, styles.videoCell]}>
                    <Text style={styles.videoCellText}>🎬</Text>
                  </View>
                  <Pressable style={styles.mediaRemove} onPress={() => { setVideoItem(null); setVideoDurationMs(null); setVideoMeta(null); }}>
                    <Text style={styles.mediaRemoveText}>×</Text>
                  </Pressable>
                </View>
              ) : (
                <Pressable style={styles.mediaAdd} onPress={pickVideo}>
                  <Svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke="#22A652" strokeWidth={2}><Path d="M12 5v14M5 12h14" /></Svg>
                </Pressable>
              )}
            </View>
            <FormError text={t("يجب رفع فيديو للإعلان (بحد أقصى ٥ دقائق)")} show={errors.has("media")} />

            <FormLabel text="صورة الغلاف" />
            <HelpBox title="صورة الغلاف">
              لو ماخترتش صورة، هناخد لقطة عشوائية من الفيديو كغلاف للإعلان تلقائيًا.
            </HelpBox>
            <View style={styles.mediaGrid}>
              {coverItem ? (
                <View style={styles.mediaCell}>
                  <Image source={{ uri: coverItem.url }} style={StyleSheet.absoluteFill} contentFit="cover" transition={150} />
                  <Pressable style={styles.mediaRemove} onPress={() => setCoverItem(null)}>
                    <Text style={styles.mediaRemoveText}>×</Text>
                  </Pressable>
                </View>
              ) : (
                <Pressable style={styles.mediaAdd} onPress={pickCoverImage}>
                  <Svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke="#22A652" strokeWidth={2}><Path d="M12 5v14M5 12h14" /></Svg>
                </Pressable>
              )}
            </View>
          </>
        ) : (
          <>
            <FormLabel text={t("صور العقار (مطلوب، حتى ١٥ صورة)")} required />
            <HelpBox title="الصورة الرئيسية">
              اضغط ☆ على أي صورة لتكون الصورة الرئيسية: هي واجهة كارت الريل في صفحة المعلن والبحث وإدارة الحساب وأول صورة في العرض التلقائي. باقي الصور تُعرض بترتيب اختيارك.
            </HelpBox>
            <Text style={styles.photoCounter}>{photoItems.length} / {MAX_PHOTOS}</Text>
            <View style={styles.mediaGrid}>
              {photoItems.map((p) => {
                const isMain = p.url === mainPhotoUrl;
                return (
                  <View key={p.url} style={[styles.mediaCell, isMain && styles.mediaCellMain]}>
                    <Image source={{ uri: p.url }} style={StyleSheet.absoluteFill} contentFit="cover" transition={150} />
                    <Pressable style={styles.mediaRemove} onPress={() => removePhoto(p.url)} hitSlop={6}>
                      <Text style={styles.mediaRemoveText}>×</Text>
                    </Pressable>
                    <Pressable style={styles.mainStar} onPress={() => setMainPhotoUrl(p.url)} hitSlop={6} accessibilityLabel={t("اجعلها الصورة الرئيسية")}>
                      <Text style={[styles.mainStarText, isMain && { color: "#FACC15" }]}>{isMain ? "★" : "☆"}</Text>
                    </Pressable>
                    {isMain && (
                      <View style={styles.mainBadge}>
                        <Text style={styles.mainBadgeText}>{t("الرئيسية")}</Text>
                      </View>
                    )}
                  </View>
                );
              })}
              {photoItems.length < MAX_PHOTOS && (
                <Pressable style={styles.mediaAdd} onPress={pickPhotos}>
                  <Svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke="#22A652" strokeWidth={2}><Path d="M12 5v14M5 12h14" /></Svg>
                </Pressable>
              )}
            </View>
            <FormError text={t("يجب إضافة صورة واحدة على الأقل (حتى ١٥ صورة)")} show={errors.has("media")} />
          </>
        )}

        <FormLabel text="موسيقى الإعلان" optional />
        <Pressable style={styles.musicHeader} onPress={toggleMusicOpen} accessibilityRole="button">
          <Text style={styles.musicNote}>🎵</Text>
          <Text style={styles.musicHeaderValue} numberOfLines={1}>{music ? music : t("بدون موسيقى")}</Text>
          <Text style={styles.musicChevron}>{musicOpen ? "▴" : "▾"}</Text>
        </Pressable>
        {musicOpen && (
          <View style={{ gap: 8, marginTop: 8 }}>
            <HelpBox title="ضبط مدة الموسيقى">
              تُضبط مدة الموسيقى تلقائيًا مع مدة الفيديو (أو عرض الصور): إن كانت أقصر تُعاد حتى تملأه بالكامل، وإن كانت أطول تُقطع عند نهايته. اضغط ▶ للاستماع قبل الاختيار.
            </HelpBox>
            <Pressable style={[styles.musicItem, music === "" && styles.musicItemActive]} onPress={() => setMusic("")}>
              <Text style={styles.musicNote}>🔇</Text>
              <Text style={styles.musicText}>{t("بدون موسيقى")}</Text>
            </Pressable>
            {musicTracks.map((track) => {
              const playing = previewingTitle === track.title;
              return (
                <Pressable
                  key={track.id}
                  style={[styles.musicItem, music === track.title && styles.musicItemActive]}
                  onPress={() => setMusic(track.title)}
                >
                  <Pressable style={[styles.previewBtn, playing && styles.previewBtnOn]} onPress={() => togglePreview(track.title)} hitSlop={8} accessibilityLabel={playing ? t("إيقاف المعاينة") : t("استماع")}>
                    <Text style={styles.previewBtnText}>{playing ? "⏸" : "▶"}</Text>
                  </Pressable>
                  <Text style={[styles.musicText, { flex: 1 }]} numberOfLines={2}>
                    {track.title}{track.description ? ` — ${t(track.description)}` : ""}
                    {track.durationSec ? `  (${Math.floor(track.durationSec / 60)}:${String(Math.round(track.durationSec % 60)).padStart(2, "0")})` : ""}
                  </Text>
                  {music === track.title && <Text style={styles.musicCheck}>✓</Text>}
                </Pressable>
              );
            })}
          </View>
        )}

        <FormLabel text="رقم التواصل (واتساب)" required />
        <PhoneInput value={phone} onChange={setPhone} error={errors.has("phone")} />
        <FormError text="من فضلك أدخل رقم صحيح" show={errors.has("phone")} />

        {/* ↔ رسوم التطبيق + إقرار ملكية الحقوق (سياسة البيع والرسوم / حقوق النشر). */}
        <View style={styles.legalBox}>
          <Text style={styles.legalTitle}>{t("رسوم التطبيق")}</Text>
          <Text style={styles.legalText}>
            {t("نشر الإعلان مجاني. يُستحق رسم")} {dealSettings.feeEgp.toLocaleString("en-US")} {t("جنيه عند إتمام البيع أو التأجير فقط، ويتحمله البائع/المؤجّر أو الوسيط وحده، ولا يتحمل المشتري أو المستأجر أي رسم.")}
          </Text>
        </View>
        {(
          <>
            <Pressable
              style={styles.rightsRow}
              onPress={() => { setRightsAccepted((v) => !v); setErrors((e) => { const n = new Set(e); n.delete("rights"); return n; }); }}
              accessibilityRole="checkbox"
              accessibilityState={{ checked: rightsAccepted }}
            >
              <View style={[styles.rightsBox, rightsAccepted && styles.rightsBoxOn, errors.has("rights") && !rightsAccepted && styles.rightsBoxError]}>
                {rightsAccepted && <Text style={styles.rightsMark}>✓</Text>}
              </View>
              <Text style={styles.rightsLabel}>
                {t("أقرّ بأنني مالك حقوق هذه الصور والفيديو أو مرخَّص لي بها، وأنها لا تحوي موسيقى أو مقاطع مقتبسة من غيري، وأتحمل المسؤولية القانونية الكاملة عن ذلك.")}
              </Text>
            </Pressable>
            <FormError text={t("يجب الإقرار بملكية الحقوق للمتابعة")} show={errors.has("rights")} />
          </>
        )}
      </ScrollView>

      {/* ↔ الشريط السفلي (نشر/مسودة) لازم يقف *فوق* شريط تنقّل النظام (أزرار أو
          إيماءات أندرويد، ومؤشر الهوم فى آيفون). قبل كده كان paddingBottom
          ثابت (26) فبيتغطّى على أي جهاز التطبيق بيترسم فيه خلف شريط النظام.
          الحل: حافة الأمان السفلية الفعلية (insets.bottom، من
          react-native-safe-area-context — بتشتغل على أندرويد/آيفون/APK،
          وعلى الويب قيمتها 0 فبيفضل الحد الأدنى 26 زي الأول). */}
      <View style={[styles.submitBar, { paddingBottom: Math.max(26, insets.bottom + 14) }]}>
        {!editingAd && (
          <Pressable style={[styles.draftBtn, savingDraft && styles.submitBtnDisabled]} onPress={handleSaveDraft} disabled={savingDraft}>
            {savingDraft ? <ActivityIndicator color="#22A652" size="small" /> : <Text style={styles.draftBtnText}>{t("حفظ كمسودة")}</Text>}
          </Pressable>
        )}
        <Pressable style={[styles.submitBtn, { flex: 1 }, submitting && styles.submitBtnDisabled]} onPress={submit} disabled={submitting}>
          {submitting ? (
            <ActivityIndicator color="white" size="small" />
          ) : (
            <Text style={styles.submitBtnText}>{editingAd ? t("حفظ") : t("نشر الإعلان")}</Text>
          )}
        </Pressable>
      </View>

      {/* ↔ مؤشر الضغط/الرفع: بيظهر طول ما عملية النشر شغالة ويمنع أي لمس أو رجوع بالغلط. */}
      <UploadProgressModal
        visible={submitting && uploadUi !== null}
        phase={uploadUi?.phase ?? "upload"}
        progress={uploadUi?.value ?? 0}
        withCompression={uploadUi?.withCompression ?? false}
      />
    </KeyboardAvoid>
  );
}

function createStyles(themeColors: ThemeColors) {
  return StyleSheet.create({
    legalBox: { backgroundColor: themeColors.surface, borderRadius: 12, padding: 12, marginTop: 18, gap: 4 },
    legalTitle: { fontSize: 13, fontWeight: "900", color: themeColors.text },
    legalText: { fontSize: 12, color: themeColors.textMuted, lineHeight: 19 },
    rightsRow: { flexDirection: "row", alignItems: "center", gap: 10, marginTop: 14 },
    rightsBox: { width: 24, height: 24, borderRadius: 7, borderWidth: 2, borderColor: themeColors.textSubtle, alignItems: "center", justifyContent: "center", backgroundColor: themeColors.surface },
    rightsBoxOn: { backgroundColor: "#22A652", borderColor: "#22A652" },
    rightsBoxError: { borderColor: "#DC2626" },
    rightsMark: { color: "white", fontSize: 14, fontWeight: "900", lineHeight: 16 },
    rightsLabel: { flex: 1, fontSize: 12.5, fontWeight: "600", color: themeColors.text, lineHeight: 20 },
    container: { flex: 1, backgroundColor: themeColors.background },
    header: { paddingTop: 50, paddingBottom: 12, paddingHorizontal: 16, flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderBottomWidth: 1, borderBottomColor: themeColors.border },
    closeBtn: { width: 34, height: 34, borderRadius: 17, backgroundColor: themeColors.surface, alignItems: "center", justifyContent: "center" },
    headerTitle: { fontSize: 14, fontWeight: "900", color: themeColors.text },
    authRequiredBox: { flex: 1, alignItems: "center", justifyContent: "center", padding: 24 },
    authRequiredTitle: { fontSize: 16, fontWeight: "900", color: themeColors.text, marginBottom: 8, textAlign: "center" },
    authRequiredSubtitle: { fontSize: 13, color: themeColors.textSubtle, textAlign: "center", marginBottom: 20 },
    authRequiredBtn: { backgroundColor: "#22A652", paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12 },
    authRequiredBtnText: { color: "white", fontWeight: "700", fontSize: 14 },
    row2: { flexDirection: "row", gap: 12 },
    hint: { fontSize: 10.5, color: themeColors.textSubtle, marginTop: 4 },
    mediaGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
    mediaCell: { width: 84, height: 84, borderRadius: 10, overflow: "hidden", backgroundColor: themeColors.surface },
    videoCell: { alignItems: "center", justifyContent: "center", backgroundColor: "#111827" },
    videoCellText: { fontSize: 22 },
    mediaRemove: { position: "absolute", top: 4, right: 4, width: 20, height: 20, borderRadius: 10, backgroundColor: "rgba(0,0,0,0.6)", alignItems: "center", justifyContent: "center" },
    mediaRemoveText: { color: "white", fontSize: 13, fontWeight: "900", marginTop: -1 },
    musicHeader: { flexDirection: "row", alignItems: "center", gap: 10, backgroundColor: themeColors.surface, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 14 },
    musicHeaderValue: { flex: 1, fontSize: 13.5, fontWeight: "700", color: themeColors.text },
    musicChevron: { color: themeColors.textSubtle, fontSize: 14 },
    previewBtn: { width: 34, height: 34, borderRadius: 17, backgroundColor: themeColors.card, borderWidth: 1.5, borderColor: "#22A652", alignItems: "center", justifyContent: "center" },
    previewBtnOn: { backgroundColor: "#22A652" },
    previewBtnText: { fontSize: 13, color: "#22A652", fontWeight: "900" },
    musicCheck: { color: "#22A652", fontSize: 16, fontWeight: "900" },
    mediaCellMain: { borderWidth: 2, borderColor: "#22A652" },
    mainStar: { position: "absolute", bottom: 3, left: 3, width: 24, height: 24, borderRadius: 12, backgroundColor: "rgba(0,0,0,0.6)", alignItems: "center", justifyContent: "center" },
    mainStarText: { color: "white", fontSize: 14, fontWeight: "900", marginTop: -1 },
    mainBadge: { position: "absolute", bottom: 0, left: 0, right: 0, backgroundColor: "rgba(34,166,82,0.92)", paddingVertical: 1, alignItems: "center" },
    mainBadgeText: { color: "white", fontSize: 9.5, fontWeight: "900" },
    photoCounter: { fontSize: 12, fontWeight: "800", color: themeColors.textSubtle, marginBottom: 6 },
    mediaAdd: { width: 84, height: 84, borderRadius: 10, borderWidth: 1.5, borderColor: "#22A652", borderStyle: "dashed", alignItems: "center", justifyContent: "center" },
    musicItem: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: themeColors.surface, borderRadius: 10, padding: 12, borderWidth: 1, borderColor: themeColors.border },
    musicItemActive: { borderColor: "#22A652", backgroundColor: themeColors.isDark ? "rgba(34,166,82,0.18)" : "#ECFDF5" },
    musicNote: { fontSize: 16 },
    musicText: { fontSize: 12.5, fontWeight: "700", color: themeColors.textMuted },
    finishSelector: { backgroundColor: themeColors.surface, borderWidth: 1, borderColor: themeColors.border, borderRadius: 12, paddingVertical: 12, paddingHorizontal: 14 },
    finishSelectorText: { fontSize: 13.5, color: themeColors.text },
    finishSelectorPlaceholder: { fontSize: 13.5, color: themeColors.textSubtle },
    finishOptions: { backgroundColor: themeColors.card, borderWidth: 1, borderColor: themeColors.border, borderRadius: 10, marginTop: 4, overflow: "hidden" },
    finishOption: { paddingVertical: 10, paddingHorizontal: 12, borderBottomWidth: 1, borderBottomColor: themeColors.border },
    finishOptionActive: { backgroundColor: themeColors.isDark ? "rgba(34,166,82,0.18)" : "#ECFDF5" },
    finishOptionText: { fontSize: 13, color: themeColors.textMuted, fontWeight: "700" },
    finishOptionActiveText: { fontSize: 13, color: themeColors.isDark ? "#6EE7B7" : "#047857", fontWeight: "800" },
    submitBar: { flexDirection: "row", gap: 10, padding: 14, paddingBottom: 26, borderTopWidth: 1, borderTopColor: themeColors.border, backgroundColor: themeColors.background },
    submitBtn: { backgroundColor: "#22A652", borderRadius: 14, paddingVertical: 15, alignItems: "center" },
    submitBtnDisabled: { backgroundColor: "#8fcaa6" },
    submitBtnText: { color: "white", fontWeight: "900", fontSize: 14 },
    draftBtn: { flex: 1, borderWidth: 1.5, borderColor: "#22A652", borderRadius: 14, paddingVertical: 15, alignItems: "center" },
    draftBtnText: { color: "#22A652", fontWeight: "900", fontSize: 13 },
  });
}